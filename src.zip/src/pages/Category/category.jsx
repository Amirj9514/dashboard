import React from "react";


const Category = () => {

  return (
    <>
      <div className=''>
        {/* <AddCategory/> */}
     </div>
     
    </>
  );
};

export default Category;


